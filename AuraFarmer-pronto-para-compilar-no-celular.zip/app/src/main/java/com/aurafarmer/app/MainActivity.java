package com.aurafarmer.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.*;

public class MainActivity extends Activity {
    Handler handler = new Handler();
    TextView timer, state, auraLabel;
    EditText auraEntry;
    long elapsed = 0, startAt = 0;
    boolean active = false;
    android.content.SharedPreferences prefs;

    Runnable tick = new Runnable() {
        public void run() {
            if (active) {
                elapsed = System.currentTimeMillis() - startAt;
                showTime();
                handler.postDelayed(this, 500);
            }
        }
    };

    int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density); }

    GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }

    TextView label(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    LinearLayout card(LinearLayout parent) {
        LinearLayout c = new LinearLayout(this); c.setOrientation(1);
        c.setPadding(dp(18), dp(18), dp(18), dp(18));
        c.setBackground(shape(0xFF21182D, 18));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(18); parent.addView(c, p); return c;
    }

    Button button(String title, int color) {
        Button b = new Button(this); b.setText(title); b.setTextColor(Color.WHITE);
        b.setTextSize(11); b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD); b.setBackground(shape(color, 12));
        return b;
    }

    void heading(LinearLayout c, String s) {
        TextView t = label(s, 11, 0xFFB99AEF, true); t.setLetterSpacing(.12f); c.addView(t);
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFF110C1D);
        getWindow().setNavigationBarColor(0xFF110C1D);
        prefs = getSharedPreferences("aura", MODE_PRIVATE);
        elapsed = prefs.getLong("elapsed", 0);
        LinearLayout page = new LinearLayout(this); page.setOrientation(1);
        page.setPadding(dp(22), dp(28), dp(22), dp(24)); page.setBackgroundColor(0xFF110C1D);

        TextView brand = label("A U R A   F A R M E R", 13, 0xFFBE91FF, true);
        page.addView(brand);
        TextView title = label("Blox Fruits", 30, Color.WHITE, true);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(-1, -2);
        tlp.topMargin = dp(8); page.addView(title, tlp);
        page.addView(label("Painel de acompanhamento de Aura", 14, 0xFFB9B0C8, false));

        LinearLayout timerCard = card(page); heading(timerCard, "TEMPO DE FARM");
        timer = label("00:00:00", 38, Color.WHITE, true); timer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams t = new LinearLayout.LayoutParams(-1, -2);
        t.topMargin = dp(14); t.bottomMargin = dp(8); timerCard.addView(timer, t);
        state = label("● PARADO", 12, 0xFFB99AEF, true); state.setGravity(Gravity.CENTER);
        timerCard.addView(state);

        LinearLayout row = new LinearLayout(this); row.setOrientation(0);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
        rp.topMargin = dp(14); timerCard.addView(row, rp);
        Button go = button("INICIAR", 0xFF8B4DE8), pause = button("PAUSAR", 0xFF49365D),
               reset = button("ZERAR", 0xFF49365D);
        for (Button x : new Button[]{go, pause, reset}) {
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, dp(48), 1);
            bp.setMargins(dp(3), 0, dp(3), 0); row.addView(x, bp);
        }
        go.setOnClickListener(v -> startTimer());
        pause.setOnClickListener(v -> pauseTimer());
        reset.setOnClickListener(v -> resetTimer());

        LinearLayout auraCard = card(page); heading(auraCard, "PROGRESSO DA AURA");
        auraLabel = label("", 18, Color.WHITE, true);
        LinearLayout.LayoutParams al = new LinearLayout.LayoutParams(-1, -2);
        al.topMargin = dp(14); auraCard.addView(auraLabel, al);
        TextView help = label("Registre seu estágio atual para acompanhar sua evolução.", 13, 0xFFB9B0C8, false);
        LinearLayout.LayoutParams hl = new LinearLayout.LayoutParams(-1, -2);
        hl.topMargin = dp(7); auraCard.addView(help, hl);
        auraEntry = new EditText(this); auraEntry.setSingleLine(true);
        auraEntry.setTextColor(Color.WHITE); auraEntry.setHintTextColor(0xFF8F849F);
        auraEntry.setHint("Ex.: Estágio 3"); auraEntry.setText(prefs.getString("stage", ""));
        auraEntry.setPadding(dp(12), 0, dp(12), 0); auraEntry.setBackground(shape(0xFF2A2038, 12));
        LinearLayout.LayoutParams el = new LinearLayout.LayoutParams(-1, dp(50));
        el.topMargin = dp(14); auraCard.addView(auraEntry, el);
        Button save = button("SALVAR PROGRESSO", 0xFF8B4DE8);
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(-1, dp(48));
        sl.topMargin = dp(10); auraCard.addView(save, sl);
        save.setOnClickListener(v -> {
            prefs.edit().putString("stage", auraEntry.getText().toString().trim()).apply();
            updateAura(); Toast.makeText(this, "Progresso salvo!", Toast.LENGTH_SHORT).show();
        });

        LinearLayout about = card(page); heading(about, "SOBRE");
        TextView note = label("Aplicativo de acompanhamento manual. Não controla o Roblox, não automatiza ações e não solicita dados da sua conta.", 13, 0xFFB9B0C8, false);
        LinearLayout.LayoutParams nl = new LinearLayout.LayoutParams(-1, -2);
        nl.topMargin = dp(12); about.addView(note, nl);
        TextView footer = label("AURA FARMER • VERSÃO 1.0", 11, 0xFF756A83, true);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams fl = new LinearLayout.LayoutParams(-1, -2);
        fl.topMargin = dp(24); page.addView(footer, fl);

        ScrollView scroll = new ScrollView(this); scroll.addView(page); setContentView(scroll);
        updateAura(); showTime();
    }

    void startTimer() {
        if (active) return;
        active = true; startAt = System.currentTimeMillis() - elapsed;
        state.setText("● EM ANDAMENTO"); handler.removeCallbacks(tick); handler.post(tick);
    }
    void pauseTimer() {
        if (!active) return;
        elapsed = System.currentTimeMillis() - startAt; active = false;
        handler.removeCallbacks(tick); state.setText("● PAUSADO"); saveTime(); showTime();
    }
    void resetTimer() {
        active = false; handler.removeCallbacks(tick); elapsed = 0;
        state.setText("● PARADO"); saveTime(); showTime();
    }
    void showTime() {
        long sec = elapsed / 1000;
        timer.setText(String.format("%02d:%02d:%02d", sec/3600, (sec%3600)/60, sec%60));
        if (!active) saveTime();
    }
    void saveTime() { prefs.edit().putLong("elapsed", elapsed).apply(); }
    void updateAura() {
        String s = prefs.getString("stage", "");
        auraLabel.setText(s.isEmpty() ? "Aura atual: não informado" : "Aura atual: " + s);
    }
    @Override protected void onPause() {
        super.onPause();
        if (active) { elapsed = System.currentTimeMillis() - startAt; saveTime(); }
    }
    @Override protected void onDestroy() { handler.removeCallbacks(tick); super.onDestroy(); }
}
